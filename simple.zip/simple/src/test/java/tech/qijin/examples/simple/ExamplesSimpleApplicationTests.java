package tech.qijin.examples.simple;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamplesSimpleApplicationTests {

	@Test
	void contextLoads() {
	}

}
