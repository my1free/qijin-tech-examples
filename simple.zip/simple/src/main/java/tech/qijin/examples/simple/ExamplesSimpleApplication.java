package tech.qijin.examples.simple;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamplesSimpleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamplesSimpleApplication.class, args);
	}

}
